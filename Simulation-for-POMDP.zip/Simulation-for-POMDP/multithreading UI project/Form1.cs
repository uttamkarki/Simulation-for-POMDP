﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace multithreading_UI_project
{
    public partial class Form1 : Form   
    {
        int hem; int con; int air; int bre; int cir;

        public Form1()
        {
            InitializeComponent();
            function1();

        }

        public void function1()
        {
            for(hem = 0; hem <= 2; hem++)
            {
                for (con = 0; con <= 2; con++)
                {
                    for (air = 0; air <= 2; air++)
                    {
                        for (bre = 0; bre <= 2; bre++)
                        {
                            for (cir = 0; cir <= 2; cir++)
                            {
                                textBox1.Text = Convert.ToString(hem);
                                textBox2.Text = Convert.ToString(con);
                                textBox3.Text = Convert.ToString(air);
                                textBox4.Text = Convert.ToString(bre);
                                textBox5.Text = Convert.ToString(cir);

                            }
                        }
                    }
                }
            }

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }


}
