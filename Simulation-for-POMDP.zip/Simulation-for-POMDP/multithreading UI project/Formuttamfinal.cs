﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using CsvHelper;
using System.IO;

namespace multithreading_UI_project
{
    public partial class Form1 : Form   
    {
        /*public static int hem1_count = 0;
        public static int hem2_count = 0;
        public static int conc1_count = 0;
        public static int conc2_count = 0;
        public static int air1_count = 0;
        public static int air2_count = 0;
        public static int airway1_count = 0;
        public static int airway2_count = 0;
        public static int breath1_count = 0;
        public static int breath2_count = 0;
        public static int circ1_count = 0;
        public static int circ2_count = 0;
        public static int total_success_count = 0;
        public static int total_partial_success_count = 0;
        public static int total_unsuccess_count = 0;*/
        public int total_hem_checked = 0;
        public int total_con_checked = 0;
        public int total_air_checked = 0;
        public int total_bre_checked = 0;
        public int total_cir_checked = 0;

        int hem; int con; int air; int bre; int cir;
        int f_hem { get; set; } int f_con { get; set; } int f_air { get; set; } int f_bre { get; set; } int f_cir { get; set; }
        List<string> POMDP_state = new List<string>();
        List<string> POMDP_action = new List<string>();
        public Form1()
        {
            InitializeComponent();
            
        }
        int a { get; set; }
        

        public void function1()
        {
            a = 1;
            var csv = new StringBuilder();
            for(hem = 0; hem <= 2; hem++)
            {
                for (con = 0; con <= 2; con++)
                {
                    for (air = 0; air <= 2; air++)
                    {
                        for (bre = 0; bre <= 2; bre++)
                        {
                            for (cir = 0; cir <= 2; cir++)
                            {
                                f_hem = hem; f_con = con; f_air = air; f_bre = bre; f_cir = cir;
                                Console.WriteLine("hem:" +hem);
                                Console.WriteLine("con:" + con);
                                Console.WriteLine("air:" + air);
                                Console.WriteLine("bre:" + bre);
                                Console.WriteLine("cir:" + cir);
                                POMDP_state.Add(Convert.ToString(hem));
                                POMDP_state.Add(Convert.ToString(con));
                                POMDP_state.Add(Convert.ToString(air));
                                POMDP_state.Add(Convert.ToString(bre));
                                POMDP_state.Add(Convert.ToString(cir));
                                Treatment();
                                POMDP_state.Add(Convert.ToString(f_hem));
                                POMDP_state.Add(Convert.ToString(f_con));
                                POMDP_state.Add(Convert.ToString(f_air));
                                POMDP_state.Add(Convert.ToString(f_bre));
                                POMDP_state.Add(Convert.ToString(f_cir));
                                POMDP_state.Add(Convert.ToString(total_hem_checked));
                                POMDP_state.Add(Convert.ToString(total_con_checked));
                                POMDP_state.Add(Convert.ToString(total_air_checked));
                                POMDP_state.Add(Convert.ToString(total_bre_checked));
                                POMDP_state.Add(Convert.ToString(total_cir_checked));
                                //var newline = "";
                                if (a == 1)
                                { var heading = string.Format($"{"Ini_Hemorrhage"},{"Ini_Consciousness"},{"Ini_Airway"},{"Ini_Breathing"},{"Ini_Circulation"},{"Time"},{"Fin_Hemorrhage"},{"Fin_Consciousness"},{"Fin_Airway"},{"Fin_Breathing"},{"Fin_Circulation"},{"Tourniquet_Applied"},{"Conciousness_Checked"},{"Airway_cleared"},{"Breathing_checked"},{"CPR_attempt"}");
                                    csv.AppendLine(heading);
                                    a = 2;
                                }
                                /*for (int i=0;i< POMDP_action.Count;i++)
                                {
                                     newline += string.Format("{0}", POMDP_action[i]);
                                }*/
                                Console.WriteLine(total_hem_checked);
                                var newline_state = string.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15}", POMDP_state[0],POMDP_state[1],POMDP_state[2],POMDP_state[3],POMDP_state[4],POMDP_state[5],POMDP_state[6],POMDP_state[7],POMDP_state[8],POMDP_state[9],POMDP_state[10],POMDP_state[11],POMDP_state[12], POMDP_state[13],POMDP_state[14],POMDP_state[15]);
                                csv.AppendLine(newline_state);
                                POMDP_state.Clear();
                                POMDP_action.Clear();
                                total_hem_checked = 0;
                                total_con_checked = 0;
                                total_bre_checked = 0;
                                total_cir_checked = 0;
                                total_air_checked = 0;
                                

                            }
                        }
                    }
                }
                
            }
            File.WriteAllText("D:\\AI_brain.csv",csv.ToString());
            textBox1.Text = "Complete";
            

        }
        
        public void Treatment()
        {
            int hem1_count = 0;
            int hem2_count = 0;
            int conc1_count = 0;
            int conc2_count = 0;
            int air1_count = 0;
            int air2_count = 0;
            int airway1_count = 0;
            int airway2_count = 0;
            int breath1_count = 0;
            int breath2_count = 0;
            int circ1_count = 0;
            int circ2_count = 0;
            int total_success_count = 0;
            int total_partial_success_count = 0;
            int total_unsuccess_count = 0;
            int time = 0;
            int time1 = 500;
            while ((f_hem + f_con + f_air + f_bre + f_cir != 0) || (f_hem == 2) && (f_con == 2) && (f_air == 2) && (f_bre == 2) && (f_cir == 2))
            {
                if(time > 100) { goto outfromwhileloop; }
                if (f_hem == 0)
                {
                    int x;
                    Random r = new Random();
                    x = r.Next(0, 101);

                    if (x <= 101) // 100% probability of successfully treating no hemorrhage
                    {
                        f_hem = 0;
                    }
                }
                else if (f_hem == 1)
                {
                    int hem1to0_cure_probability = 90 - (5 * hem1_count);
                    int hem1to1_cure_probability = 10 + (5 * hem1_count);
                    int hem1_cure_cumprob = hem1to1_cure_probability + hem1to0_cure_probability;

                    int x;
                    Random r = new Random();
                    x = r.Next(0, 101);
                    if (x <= hem1to0_cure_probability)
                    {
                        f_hem = 0;
                        total_success_count = total_success_count + 1;
                    }
                    else
                    {
                        f_hem = 1;
                        total_unsuccess_count = total_unsuccess_count + 1;
                    }

                    hem1_count = hem1_count + 1;
                    POMDP_action.Add("Tourniquet Applied");
                    time = time + 3;
                }
                else // ...if hemorrhage = 2
                {
                    int hem2to0_cure_probability = 30 - (3 * hem2_count);
                    int hem2to1_cure_probability = 60 - (3 * hem2_count);
                    int hem2to2_cure_probability = 10 + (6 * hem2_count);
                    int hem2to1_cumprob = hem2to1_cure_probability + hem2to0_cure_probability;
                    int hem2_cure_cumprob = hem2to1_cure_probability + hem2to0_cure_probability + hem2to2_cure_probability;

                    int x;
                    Random r = new Random();
                    x = r.Next(0, 101);
                    if (x <= hem2to0_cure_probability)
                    {
                        f_hem = 0;
                        total_success_count = total_success_count + 1;
                    }
                    else if (x <= hem2to1_cumprob && x > hem2to0_cure_probability)
                    {
                        f_hem = 1;
                        total_partial_success_count = total_partial_success_count + 1;
                    }
                    else
                    {
                        f_hem = 2;
                        total_unsuccess_count = total_unsuccess_count + 1;
                    }

                    hem2_count = hem2_count + 1;
                    POMDP_action.Add("Tourniquet Applied");
                    time = time + 3;
                }
                //Consciousness

                int conc1to0_cure_probability;
                int conc1to1_cure_probability = 0;
                int conc2to0_cure_probability = 10;

                int conc2to1_cure_probability = 50;
                int conc2to2_cure_probability = 40;
                int conc2to1_cumprob = conc2to1_cure_probability + conc2to0_cure_probability;
                
                if (f_con == 0)
                {
                    f_con = 0;
                }
                else if (f_con == 1)
                {

                    if (f_bre == 0 && f_hem == 0 && f_air == 0 && f_cir == 0)
                    {
                        conc1to0_cure_probability = 60 + (5 * conc1_count);
                        conc1to1_cure_probability = 40 - (5 * conc1_count);
                    }
                    else
                    {
                        conc1to0_cure_probability = 60 - (5 * conc1_count);
                        conc1to1_cure_probability = 40 + (5 * conc1_count);
                    }

                    int conc1_cure_cumprob = conc1to1_cure_probability + conc1to0_cure_probability;
                    int x;

                    Random r = new Random();
                    x = r.Next(0, 101);
                    if (x <= conc1to0_cure_probability)
                    {
                        f_con = 0;
                        total_success_count = total_success_count + 1;
                    }
                    else
                    {
                        f_con = 1;
                        total_unsuccess_count = total_unsuccess_count + 1;
                    }
                    conc1_count = conc1_count + 1;
                    POMDP_action.Add("Consciousness Checked");
                    time = time + 3;
                }
                else // ...if consciousness = 2
                {
                    if (f_bre == 0 && f_hem == 0 && f_air == 0 && f_cir == 0)
                    {
                        conc2to0_cure_probability = 10 + (2 * conc2_count);
                        conc2to1_cure_probability = 50 + (8 * conc2_count);
                        conc2to2_cure_probability = 40 - (10 * conc2_count);
                        conc2to1_cumprob = conc2to1_cure_probability + conc2to0_cure_probability;
                    }
                    else
                    {
                        conc2to0_cure_probability = 10 - (1 * conc2_count);
                        conc2to1_cure_probability = 50 - (4 * conc2_count);
                        conc2to2_cure_probability = 40 + (5 * conc2_count);
                        conc2to1_cumprob = conc2to1_cure_probability + conc2to0_cure_probability;
                    }


                    int x;
                    Random r = new Random();
                    x = r.Next(0, 101);
                    if (x <= conc2to0_cure_probability)
                    {
                        f_con = 0;
                        total_success_count = total_success_count + 1;
                    }
                    else if (x <= conc2to1_cumprob && x > conc2to0_cure_probability)
                    {
                        f_con = 1;
                        total_partial_success_count = total_partial_success_count + 1;
                    }
                    else
                    {
                        f_con = 2;
                        total_unsuccess_count = total_unsuccess_count + 1;
                    }
                    conc2_count = conc2_count + 1;
                    POMDP_action.Add("Consciousness Checked");
                    time = time + 3;
                }

                //airway
                if (f_air == 0)
                {
                    f_air = 0;
                }
                else if (f_air == 1)
                {
                    int air1to0_cure_probability = 80;
                    int x;
                    Random r = new Random();
                    x = r.Next(0, 101);
                    if (x <= air1to0_cure_probability)
                    {
                        f_air = 0;
                        total_success_count = total_success_count + 1;
                    }
                    else
                    {
                        f_air = 1;
                        total_unsuccess_count = total_unsuccess_count + 1;
                    }
                    air1_count = air1_count + 1;
                    POMDP_action.Add("Airway Clear Attempt");
                    time = time + 3;
                }
                else // ...if airway = 2
                {
                    int air2to0_cure_probability = 30;
                    int air2to1_cure_probability = 30;
                    int air2to2_cure_probability = 40;
                    int air2to1_cumprob = air2to1_cure_probability + air2to0_cure_probability;
                    int air2_cure_cumprob = air2to1_cure_probability + air2to0_cure_probability + air2to2_cure_probability;
                    int x;
                    Random r = new Random();
                    x = r.Next(0, 101);
                    if (x <= air2to0_cure_probability)
                    {
                        f_air = 0;
                        total_success_count = total_success_count + 1;
                    }
                    else if (x <= air2to1_cumprob && x > air2to0_cure_probability)
                    {
                        f_air = 1;
                        total_partial_success_count = total_partial_success_count + 1;
                    }
                    else
                    {
                        f_air = 2;
                        total_unsuccess_count = total_unsuccess_count + 1;
                    }
                    air2_count = air2_count + 1;
                    POMDP_action.Add("Airway Clear Attempt");
                    time = time + 3;
                }

                // breathing
                int breath1to0_cure_probability = 60;
                int breath1_successprob_reduction = 5;
                int breath2to0_cure_probability = 10;
                int breath2to1_cure_probability = 60;
                int breath2to1_cumprob = breath2to1_cure_probability + breath2to0_cure_probability;
                int breath2_successprob_reduction = 5;
                
                if (f_bre == 0)
                {
                    f_bre = 0;
                }
                else if (f_bre == 1)
                {
                    breath1to0_cure_probability = breath1to0_cure_probability - (breath1_successprob_reduction * breath1_count);
                    int x;
                    Random r = new Random();
                    x = r.Next(0, 101);
                    if (x <= breath1to0_cure_probability)
                    {
                        f_bre = 0;
                        total_success_count = total_success_count + 1;
                    }
                    else
                    {
                        f_bre = 1;
                        total_unsuccess_count = total_unsuccess_count + 1;
                    }
                    breath1_count = breath1_count + 1;
                    POMDP_action.Add("Breathing Checked");
                    time = time + 3;
                }
                else // ...if breathing = 2
                {
                    breath2to0_cure_probability = breath2to0_cure_probability - (breath2_successprob_reduction * breath2_count);
                    breath2to1_cure_probability = breath2to1_cure_probability - (breath2_successprob_reduction * breath2_count);
                    breath2to1_cumprob = breath2to1_cure_probability + breath2to0_cure_probability;

                    int x;
                    Random r = new Random();
                    x = r.Next(0, 101);
                    if (x <= breath2to0_cure_probability)
                    {
                        f_bre = 0;
                        total_success_count = total_success_count + 1;
                    }
                    else if (x <= breath2to1_cumprob && x > breath2to0_cure_probability)
                    {
                        f_bre = 1;
                        total_partial_success_count = total_partial_success_count + 1;
                    }
                    else
                    {
                        f_bre = 2;
                        total_unsuccess_count = total_unsuccess_count + 1;
                    }
                    POMDP_action.Add("Breathing Checked");
                    time = time + 3;
                }

                //circulation
                int circ1to0_cure_probability = 70; // the probability that circulation treatment from level 1 to 0 is successful
                int circ1_successprob_reduction = 5; // the reduction in the probability of success with each repeated treatment from level 1

                int circ2to0_cure_probability = 10; // the probability that circulation treatment from level 2 to 0 is successful
                int circ2to1_cure_probability = 10; // the probability that circulation treatment from level 2 to 1 is successful
                int circ2to1_cumprob = circ2to1_cure_probability + circ2to0_cure_probability; // cumulative success probabiligy
                int circ2_0_successprob_reduction = 1; // the reduction in the probability of success with each repeated treatment from level 2 to 0
                int circ2_1_successprob_reduction = 1; // the reduction in the probability of success with each repeated treatment from level 2 to 1

                int circ_timedelay = 0;
                int circ1_timedelay = 3000;
                int circ2_timedelay = 5000;
                
                if (f_cir == 0)  // If there is no problem
                {
                    f_cir = 0;                                                            //set patient condition quantifier to 0 'normal'
                }
                else if (f_cir == 1)  // if there is a minor problem
                {
                    circ1to0_cure_probability -= (circ1_successprob_reduction * circ1_count);    //partial success probability accounting for repeat procedures
                    int x;
                    Random r = new Random();
                    x = r.Next(0, 101);                                                         //generate random number between 1 and 100 for outcome 
                    if (x <= circ1to0_cure_probability)
                    {
                        f_cir = 0;                                                      //patient condition quantifier set to 0 - 'normal'
                        total_success_count += 1;                                             //global counter for successful procedures
                    }
                    else
                    {
                        f_cir = 1;                                                        //Patient condition quantifier set to 1 - no change - still some problem
                        total_unsuccess_count += 1;                                             //global counter for unsucessful procedures
                    }
                    circ1_count += 1;                                                           //counter for level 1 circulation procedures (successful or unsuccessful)
                    circ_timedelay = circ1_timedelay;                                           //set appropriate time delay for a level 1 procedure
                    POMDP_action.Add("CPR attempt");
                    time = time + 3;
                }
                else // ...if patient is critical or there is a serious problem
                {
                    
                    circ2to0_cure_probability -= (circ2_0_successprob_reduction * circ2_count); //complete success probability accounting for repeats
                    circ2to1_cure_probability -= (circ2_1_successprob_reduction * circ2_count); //partial success probability accounting for repeats
                    circ2to1_cumprob = circ2to1_cure_probability + circ2to0_cure_probability;   // set cumulative success and partial success probability

                    int x;
                    Random r = new Random();
                    x = r.Next(0, 101);                                                         //generate random number between 1 and 100
                    if (x <= circ2to0_cure_probability)
                    {
                        f_cir = 0;                                                        // patient condition quantifier set to 0 - 'normal'
                        total_success_count += 1;                                               // global counter for successful procedures
                    }
                    else if (x <= circ2to1_cumprob && x > circ2to0_cure_probability)
                    {
                        f_cir = 1;                                                        //patient condition quantifier set to 1 - some problems
                        total_partial_success_count += 1;                                       // counter for partial successful procedures
                    }
                    else
                    {      
                        f_cir = 2;                                                        //patient condition quantifier set to 2 - critical
                        total_unsuccess_count += 1;                                             // counter for unsuccessful procedures
                    }
                    circ2_count += 1;                                                           //counter for total critical procedures (successful and unsuccessful)
                    circ_timedelay = circ2_timedelay;                                           //set timedelay to variable for critical procedure
                    POMDP_action.Add("CPR attempt");
                    time = time + 3;
                }

            }
            outfromwhileloop:
            total_hem_checked = hem1_count + hem2_count;
            total_con_checked = conc1_count + conc2_count;
            total_air_checked = air1_count + air2_count;
            total_bre_checked = breath1_count + breath2_count; ;
            total_cir_checked = circ1_count + circ2_count;
            if (((f_hem == 0) && (f_con == 0) && (f_air == 0) && (f_bre == 0) && 
                (f_cir == 0)) || ((f_hem == 2) && (f_con == 2) && (f_air == 2) && (f_bre == 2) && (f_cir == 2)) || time >= 100)
            {
                if (time < time1)
                {
                    time1 = time;
                }
                else {  }
                POMDP_state.Add((Convert.ToString(time1)));
            }
            else { }


        }// treatmnet ends
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            function1();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int i = 3;
            using (var reader = new StreamReader("D:\\AI_brain.csv"))
            {
                List<string> list_ini_hem = new List<string>();
                List<string> list_ini_con = new List<string>();
                List<string> list_ini_air = new List<string>();
                List<string> list_ini_bre = new List<string>();
                List<string> list_ini_cir = new List<string>();
                List<string> list_time = new List<string>();
                List<string> list_fin_hem = new List<string>();
                List<string> list_fin_con = new List<string>();
                List<string> list_fin_air = new List<string>();
                List<string> list_fin_bre = new List<string>();
                List<string> list_fin_cir = new List<string>();
                List<string> list_tourniquet_count = new List<string>();
                List<string> list_consciousness_count = new List<string>();
                List<string> list_airway_count = new List<string>();
                List<string> list_breathing_count = new List<string>();
                List<string> list_circulation_count = new List<string>();
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(',');

                    list_ini_hem.Add(values[0]);
                    list_ini_con.Add(values[1]);
                    list_ini_air.Add(values[2]);
                    list_ini_bre.Add(values[3]);
                    list_ini_cir.Add(values[4]);
                    list_time.Add(values[5]);
                    list_fin_hem.Add(values[6]);
                    list_fin_con.Add(values[7]);
                    list_fin_air.Add(values[8]);
                    list_fin_bre.Add(values[9]);
                    list_fin_cir.Add(values[10]);
                    //list_action.Add(values[11]);
                    list_tourniquet_count.Add(values[11]);
                    list_consciousness_count.Add(values[12]);
                    list_airway_count.Add(values[13]);
                    list_breathing_count.Add(values[14]);
                    list_circulation_count.Add(values[15]);

                }
                Console.WriteLine(Convert.ToString(list_tourniquet_count[i]));
                textBox10.Text = Convert.ToString(list_ini_hem[i]);
                textBox9.Text = Convert.ToString(list_ini_con[i]);
                textBox8.Text = Convert.ToString(list_ini_air[i]);
                textBox7.Text = Convert.ToString(list_ini_bre[i]);
                textBox6.Text = Convert.ToString(list_ini_cir[i]);
                textBox11.Text = Convert.ToString(list_circulation_count[i]);
                textBox12.Text = Convert.ToString(list_breathing_count[i]);
                textBox13.Text = Convert.ToString(list_airway_count[i]);
                textBox14.Text = Convert.ToString(list_consciousness_count[i]);
                textBox15.Text = Convert.ToString(list_tourniquet_count[i]);
            }
        }
    }


}
