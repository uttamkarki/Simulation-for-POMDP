﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using CsvHelper;
using System.IO;

namespace multithreading_UI_project
{
    public partial class Form1 : Form   
    {
        public static int hem1_count = 0;
        public static int hem2_count = 0;
        public static int conc1_count = 0;
        public static int conc2_count = 0;
        public static int air1_count = 0;
        public static int air2_count = 0;
        public static int airway1_count = 0;
        public static int airway2_count = 0;
        public static int breath1_count = 0;
        public static int breath2_count = 0;
        public static int circ1_count = 0;
        public static int circ2_count = 0;
        public static int total_success_count = 0;
        public static int total_partial_success_count = 0;
        public static int total_unsuccess_count = 0;

        int hem; int con; int air; int bre; int cir;
        int f_hem { get; set; } int f_con { get; set; } int f_air { get; set; } int f_bre { get; set; } int f_cir { get; set; }

        public Form1()
        {
            InitializeComponent();

        }

        public void function1()
        {
            var csv = new StringBuilder();
            for(hem = 0; hem <= 2; hem++)
            {
                for (con = 0; con <= 2; con++)
                {
                    for (air = 0; air <= 2; air++)
                    {
                        for (bre = 0; bre <= 2; bre++)
                        {
                            for (cir = 0; cir <= 2; cir++)
                            {
                                f_hem = hem; f_con = con; f_air = air; f_bre = bre; f_cir = cir;
                                Console.WriteLine("hem:" +hem);
                                Console.WriteLine("con:" + con);
                                Console.WriteLine("air:" + air);
                                Console.WriteLine("bre:" + bre);
                                Console.WriteLine("cir:" + cir);
                                Treatment();
                                var newline = string.Format("{0},{1},{2},{3},{4}", Convert.ToString(hem), Convert.ToString(con),
                                    Convert.ToString(air), Convert.ToString(bre), Convert.ToString(cir));
                                csv.AppendLine(newline);

                            }
                        }
                    }
                }
                
            }
            File.WriteAllText("D:\\AI_brain.csv",csv.ToString());
            textBox1.Text = "Complete";
            

        }

        public void Treatment()
        {
            while(((f_hem!=0) && (f_con != 0) && (f_air != 0) && (f_bre != 0) && (f_cir != 0))|| ((f_hem != 2) && (f_con != 2) && (f_air != 2) && (f_bre != 2) && (f_cir != 2)))
            {
                if (f_hem == 0)
                {
                    int x;
                    Random r = new Random();
                    x = r.Next(0, 101);

                    if (x <= 101) // 100% probability of successfully treating no hemorrhage
                    {
                        f_hem = 0;
                    }
                }
                else if (f_hem == 1)
                {
                    int hem1to0_cure_probability = 90 - (5 * hem1_count);
                    int hem1to1_cure_probability = 10 + (5 * hem1_count);
                    int hem1_cure_cumprob = hem1to1_cure_probability + hem1to0_cure_probability;

                    int x;
                    Random r = new Random();
                    x = r.Next(0, 101);
                    if (x <= hem1to0_cure_probability)
                    {
                        f_hem = 0;
                        total_success_count = total_success_count + 1;
                    }
                    else
                    {
                        f_hem = 1;
                        total_unsuccess_count = total_unsuccess_count + 1;
                    }

                    hem1_count = hem1_count + 1;
                }


            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            function1();
        }
    }


}
